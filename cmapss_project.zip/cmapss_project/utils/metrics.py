"""
Evaluation Metrics
==================
RMSE and the asymmetric PHM scoring function from the C-MAPSS benchmark.
"""

import numpy as np
import torch


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Root Mean Squared Error."""
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def phm_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """
    Asymmetric PHM scoring function.
    Penalises late predictions (d >= 0) more heavily than early ones (d < 0).

        s_i = exp(-d_i / 13) - 1   if d_i < 0  (early prediction)
        s_i = exp( d_i / 10) - 1   if d_i >= 0 (late prediction)

    where d_i = y_pred_i - y_true_i.

    Returns the sum of individual scores (standard convention).
    """
    d = y_pred - y_true
    scores = np.where(d < 0, np.exp(-d / 13) - 1, np.exp(d / 10) - 1)
    return float(np.sum(scores))


def evaluate(model, loader, device, denorm_scale: float = 1.0):
    """
    Run model on a DataLoader and return (rmse, phm, y_true, y_pred).

    denorm_scale: multiply predictions/labels back to cycles if you
                  normalised RUL during training (default 1.0 = no scaling).
    """
    model.eval()
    all_pred, all_true = [], []

    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            pred = model(x).squeeze(-1).cpu().numpy() * denorm_scale
            true = y.numpy() * denorm_scale
            all_pred.append(pred)
            all_true.append(true)

    y_pred = np.concatenate(all_pred)
    y_true = np.concatenate(all_true)

    return rmse(y_true, y_pred), phm_score(y_true, y_pred), y_true, y_pred
