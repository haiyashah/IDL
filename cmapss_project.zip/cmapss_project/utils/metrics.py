import numpy as np
import torch

def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred)**2)))

def phm_score(y_true, y_pred):
    d = y_pred - y_true
    scores = np.where(d < 0, np.exp(-d/13)-1, np.exp(d/10)-1)
    return float(np.sum(scores))

def evaluate(model, loader, device):
    model.eval()
    preds, trues = [], []
    with torch.no_grad():
        for x, y in loader:
            p = model(x.to(device)).squeeze(-1).cpu().numpy()
            preds.append(p)
            trues.append(y.numpy())
    y_pred = np.concatenate(preds)
    y_true = np.concatenate(trues)
    return rmse(y_true, y_pred), phm_score(y_true, y_pred), y_true, y_pred
