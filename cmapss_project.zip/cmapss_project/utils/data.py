import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import torch
from torch.utils.data import Dataset, DataLoader

COLS = (["unit","cycle"] + [f"op_{i}" for i in range(1,4)] + [f"s{i}" for i in range(1,22)])
DEAD_SENSORS = ["s1","s5","s6","s10","s16","s18","s19"]
ACTIVE_SENSORS = [f"s{i}" for i in range(1,22) if f"s{i}" not in DEAD_SENSORS]
OP_SETTINGS = ["op_1","op_2","op_3"]
FEATURE_COLS = OP_SETTINGS + ACTIVE_SENSORS
MAX_RUL = 125

def _load_raw(path):
    return pd.read_csv(path, sep=r"\s+", header=None, names=COLS)

def _compute_rul(df):
    mx = df.groupby("unit")["cycle"].max().rename("max_cycle")
    df = df.join(mx, on="unit")
    df["rul"] = (df["max_cycle"] - df["cycle"]).clip(upper=MAX_RUL)
    df.drop(columns=["max_cycle"], inplace=True)
    return df

def _normalize(train_df, test_df):
    scaler = MinMaxScaler()
    train_df = train_df.copy()
    test_df = test_df.copy()
    train_df[FEATURE_COLS] = scaler.fit_transform(train_df[FEATURE_COLS])
    test_df[FEATURE_COLS] = scaler.transform(test_df[FEATURE_COLS])
    return train_df, test_df, scaler

class CMAPSSDataset(Dataset):
    def __init__(self, df, rul_series, seq_len=30, is_test=False):
        self.X = []
        self.y = []
        if is_test:
            for uid, grp in df.groupby("unit"):
                feats = grp[FEATURE_COLS].values
                if len(feats) < seq_len:
                    pad = np.zeros((seq_len - len(feats), feats.shape[1]))
                    feats = np.vstack([pad, feats])
                self.X.append(feats[-seq_len:])
                self.y.append(float(rul_series.loc[uid]))
        else:
            for _, grp in df.groupby("unit"):
                feats = grp[FEATURE_COLS].values
                ruls = grp["rul"].values
                n = len(feats)
                for start in range(n - seq_len + 1):
                    self.X.append(feats[start:start+seq_len])
                    self.y.append(float(ruls[start+seq_len-1]))

    def __len__(self): return len(self.X)
    def __getitem__(self, idx):
        return (torch.tensor(self.X[idx], dtype=torch.float32),
                torch.tensor(self.y[idx], dtype=torch.float32))

def load_cmapss(data_dir, subset="FD001", seq_len=30, batch_size=64,
                val_fraction=0.1, num_workers=0, seed=42):
    train_df = _load_raw(os.path.join(data_dir, f"train_{subset}.txt"))
    test_df  = _load_raw(os.path.join(data_dir, f"test_{subset}.txt"))
    rul_raw  = pd.read_csv(os.path.join(data_dir, f"RUL_{subset}.txt"), header=None, names=["rul"])
    rul_raw["rul"] = rul_raw["rul"].clip(upper=MAX_RUL)
    rul_series = rul_raw["rul"]
    rul_series.index = rul_series.index + 1
    train_df = _compute_rul(train_df)
    train_df, test_df, _ = _normalize(train_df, test_df)
    rng = np.random.default_rng(seed)
    all_units = train_df["unit"].unique()
    n_val = max(1, int(len(all_units) * val_fraction))
    val_units = rng.choice(all_units, size=n_val, replace=False)
    train_units = np.setdiff1d(all_units, val_units)
    tr = CMAPSSDataset(train_df[train_df["unit"].isin(train_units)], rul_series, seq_len)
    vl = CMAPSSDataset(train_df[train_df["unit"].isin(val_units)], rul_series, seq_len)
    te = CMAPSSDataset(test_df, rul_series, seq_len, is_test=True)
    return (DataLoader(tr, batch_size=batch_size, shuffle=True, num_workers=num_workers),
            DataLoader(vl, batch_size=batch_size, shuffle=False, num_workers=num_workers),
            DataLoader(te, batch_size=batch_size, shuffle=False, num_workers=num_workers),
            len(FEATURE_COLS))
