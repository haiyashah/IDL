"""
C-MAPSS Data Loading and Preprocessing Pipeline
================================================
Handles FD001–FD004 subsets. Applies sliding window, RUL clipping,
sensor normalization, and returns PyTorch DataLoaders.
"""

import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import torch
from torch.utils.data import Dataset, DataLoader

# ------------------------------------------------------------------
# Column names (data files have no header)
# ------------------------------------------------------------------
COLS = (
    ["unit", "cycle"]
    + [f"op_{i}" for i in range(1, 4)]
    + [f"s{i}" for i in range(1, 22)]
)

# Sensors that are nearly constant across all subsets — drop them
DEAD_SENSORS = ["s1", "s5", "s6", "s10", "s16", "s18", "s19"]

# Active sensors used as features
ACTIVE_SENSORS = [f"s{i}" for i in range(1, 22) if f"s{i}" not in DEAD_SENSORS]
OP_SETTINGS = ["op_1", "op_2", "op_3"]
FEATURE_COLS = OP_SETTINGS + ACTIVE_SENSORS  # 17 features total

MAX_RUL = 125  # Standard piecewise-linear RUL cap


# ------------------------------------------------------------------
# Low-level loaders
# ------------------------------------------------------------------

def _load_raw(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, sep=r"\s+", header=None, names=COLS)
    return df


def _compute_rul(df: pd.DataFrame) -> pd.DataFrame:
    """Attach RUL column (clipped at MAX_RUL) to training data."""
    max_cycle = df.groupby("unit")["cycle"].max().rename("max_cycle")
    df = df.join(max_cycle, on="unit")
    df["rul"] = (df["max_cycle"] - df["cycle"]).clip(upper=MAX_RUL)
    df.drop(columns=["max_cycle"], inplace=True)
    return df


def _normalize(train_df: pd.DataFrame, test_df: pd.DataFrame):
    """Fit scaler on train features, transform both splits."""
    scaler = MinMaxScaler()
    train_df = train_df.copy()
    test_df = test_df.copy()
    train_df[FEATURE_COLS] = scaler.fit_transform(train_df[FEATURE_COLS])
    test_df[FEATURE_COLS] = scaler.transform(test_df[FEATURE_COLS])
    return train_df, test_df, scaler


# ------------------------------------------------------------------
# Sliding window dataset
# ------------------------------------------------------------------

class CMAPSSDataset(Dataset):
    """
    Sliding-window dataset for C-MAPSS.

    Each sample is a window of `seq_len` consecutive time steps
    for one engine unit. The label is the RUL at the last step.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        rul_series: pd.Series,
        seq_len: int = 30,
        is_test: bool = False,
    ):
        self.seq_len = seq_len
        self.is_test = is_test
        self.X: list[np.ndarray] = []
        self.y: list[float] = []

        if is_test:
            # For test set: one window per engine (last seq_len steps)
            for unit_id, group in df.groupby("unit"):
                feats = group[FEATURE_COLS].values
                if len(feats) < seq_len:
                    # Pad with zeros at the front if trajectory is short
                    pad = np.zeros((seq_len - len(feats), feats.shape[1]))
                    feats = np.vstack([pad, feats])
                self.X.append(feats[-seq_len:])
                self.y.append(float(rul_series.loc[unit_id]))
        else:
            # For train set: sliding window over each unit
            for _, group in df.groupby("unit"):
                feats = group[FEATURE_COLS].values
                ruls = group["rul"].values
                n = len(feats)
                for start in range(n - seq_len + 1):
                    self.X.append(feats[start : start + seq_len])
                    self.y.append(float(ruls[start + seq_len - 1]))

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        x = torch.tensor(self.X[idx], dtype=torch.float32)
        y = torch.tensor(self.y[idx], dtype=torch.float32)
        return x, y


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------

def load_cmapss(
    data_dir: str,
    subset: str = "FD001",
    seq_len: int = 30,
    batch_size: int = 64,
    val_fraction: float = 0.1,
    num_workers: int = 0,
    seed: int = 42,
):
    """
    Load a C-MAPSS subset and return DataLoaders.

    Parameters
    ----------
    data_dir : str
        Directory containing the raw .txt files
        (train_FD001.txt, test_FD001.txt, RUL_FD001.txt, …).
    subset : str
        One of 'FD001', 'FD002', 'FD003', 'FD004'.
    seq_len : int
        Sliding window length.
    batch_size : int
    val_fraction : float
        Fraction of training units held out for validation.
    num_workers : int
    seed : int

    Returns
    -------
    train_loader, val_loader, test_loader : DataLoader
    n_features : int   (17)
    """
    assert subset in {"FD001", "FD002", "FD003", "FD004"}, f"Unknown subset {subset}"

    train_path = os.path.join(data_dir, f"train_{subset}.txt")
    test_path = os.path.join(data_dir, f"test_{subset}.txt")
    rul_path = os.path.join(data_dir, f"RUL_{subset}.txt")

    train_df = _load_raw(train_path)
    test_df = _load_raw(test_path)
    rul_raw = pd.read_csv(rul_path, header=None, names=["rul"])

    # Clip test RUL at MAX_RUL as well
    rul_raw["rul"] = rul_raw["rul"].clip(upper=MAX_RUL)

    # Map unit id (1-indexed) → true RUL
    rul_series = rul_raw["rul"]
    rul_series.index = rul_series.index + 1  # 1-indexed units

    # Attach RUL to train
    train_df = _compute_rul(train_df)

    # Normalize
    train_df, test_df, _ = _normalize(train_df, test_df)

    # Train / val split by unit id
    rng = np.random.default_rng(seed)
    all_units = train_df["unit"].unique()
    n_val = max(1, int(len(all_units) * val_fraction))
    val_units = rng.choice(all_units, size=n_val, replace=False)
    train_units = np.setdiff1d(all_units, val_units)

    tr_df = train_df[train_df["unit"].isin(train_units)]
    vl_df = train_df[train_df["unit"].isin(val_units)]

    train_ds = CMAPSSDataset(tr_df, rul_series, seq_len=seq_len, is_test=False)
    val_ds = CMAPSSDataset(vl_df, rul_series, seq_len=seq_len, is_test=False)
    test_ds = CMAPSSDataset(test_df, rul_series, seq_len=seq_len, is_test=True)

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )
    test_loader = DataLoader(
        test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )

    return train_loader, val_loader, test_loader, len(FEATURE_COLS)


if __name__ == "__main__":
    import sys
    data_dir = sys.argv[1] if len(sys.argv) > 1 else "./data/CMAPSSData"
    tr, vl, te, nf = load_cmapss(data_dir, subset="FD001")
    print(f"n_features={nf}  train={len(tr.dataset)}  val={len(vl.dataset)}  test={len(te.dataset)}")
    x, y = next(iter(tr))
    print(f"Batch x: {x.shape}  y: {y.shape}")
