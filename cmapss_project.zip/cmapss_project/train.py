import argparse, os, json
import numpy as np
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau

try:
    import wandb
    WANDB = True
except ImportError:
    WANDB = False

from utils.data import load_cmapss
from utils.metrics import evaluate
from models.lstm_baseline import LSTMBaseline
from models.tft import TemporalFusionTransformer

DEFAULTS = {
    "lstm": dict(hidden_size=128, num_layers=2, dropout=0.2, lr=1e-3, batch_size=64),
    "tft":  dict(d_model=64, n_heads=4, n_lstm_layers=2, dropout=0.1, lr=5e-4, batch_size=64),
}

def build_model(name, n_features, hp):
    if name == "lstm":
        return LSTMBaseline(n_features, hp["hidden_size"], hp["num_layers"], hp["dropout"])
    return TemporalFusionTransformer(n_features, hp["d_model"], hp["n_heads"], hp["n_lstm_layers"], hp["dropout"])

def train_epoch(model, loader, opt, criterion, device):
    model.train()
    total = 0.0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        opt.zero_grad()
        loss = criterion(model(x).squeeze(-1), y)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        total += loss.item() * len(y)
    return total / len(loader.dataset)

def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    hp = DEFAULTS[args.model].copy()
    hp.update({"subset": args.subset, "epochs": args.epochs})

    if WANDB and not args.no_wandb:
        wandb.init(project="cmapss-rul", name=f"{args.model}_{args.subset}", config=hp)

    tr, vl, te, nf = load_cmapss(args.data_dir, args.subset, batch_size=hp["batch_size"])
    model = build_model(args.model, nf, hp).to(device)
    print(f"Model: {args.model.upper()}  Params: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    opt = Adam(model.parameters(), lr=hp["lr"], weight_decay=1e-4)
    sched = ReduceLROnPlateau(opt, patience=5, factor=0.5, min_lr=1e-6)
    criterion = nn.MSELoss()

    os.makedirs(args.checkpoint_dir, exist_ok=True)
    os.makedirs(args.results_dir, exist_ok=True)
    ckpt = os.path.join(args.checkpoint_dir, f"{args.model}_{args.subset}_best.pt")
    best_rmse = float("inf")
    history = []

    for epoch in range(1, args.epochs+1):
        tl = train_epoch(model, tr, opt, criterion, device)
        vr, vp, _, _ = evaluate(model, vl, device)
        sched.step(vr)
        lr = opt.param_groups[0]["lr"]
        print(f"Epoch {epoch:03d}/{args.epochs}  train_loss={tl:.4f}  val_rmse={vr:.4f}  val_phm={vp:.2f}  lr={lr:.2e}")
        if WANDB and not args.no_wandb:
            wandb.log({"epoch": epoch, "train_loss": tl, "val_rmse": vr, "val_phm": vp})
        history.append({"epoch": epoch, "train_loss": tl, "val_rmse": vr, "val_phm": vp})
        if vr < best_rmse:
            best_rmse = vr
            torch.save({"epoch": epoch, "model_state": model.state_dict(),
                        "val_rmse": vr, "model_name": args.model, "subset": args.subset}, ckpt)
            print(f"  saved checkpoint (val_rmse={vr:.4f})")

    saved = torch.load(ckpt, map_location=device)
    model.load_state_dict(saved["model_state"])
    test_rmse, test_phm, y_true, y_pred = evaluate(model, te, device)
    print(f"\n=== Test Results ({args.model.upper()} / {args.subset}) ===")
    print(f"  RMSE : {test_rmse:.4f}")
    print(f"  PHM  : {test_phm:.2f}")

    if WANDB and not args.no_wandb:
        wandb.log({"test_rmse": test_rmse, "test_phm": test_phm})
        wandb.finish()

    results = {"model": args.model, "subset": args.subset, "test_rmse": test_rmse,
               "test_phm": test_phm, "best_val_rmse": best_rmse, "history": history,
               "y_true": y_true.tolist(), "y_pred": y_pred.tolist()}
    rp = os.path.join(args.results_dir, f"{args.model}_{args.subset}.json")
    with open(rp, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Results saved to {rp}")
    return test_rmse, test_phm

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model", choices=["lstm","tft"], default="lstm")
    p.add_argument("--subset", choices=["FD001","FD002","FD003","FD004"], default="FD001")
    p.add_argument("--data_dir", default="./data/CMAPSSData")
    p.add_argument("--checkpoint_dir", default="./checkpoints")
    p.add_argument("--results_dir", default="./results")
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--no_wandb", action="store_true")
    return p.parse_args()

if __name__ == "__main__":
    train(parse_args())
