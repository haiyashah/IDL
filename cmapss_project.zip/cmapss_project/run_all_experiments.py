import argparse, subprocess, sys, json, os

EXPERIMENTS = [("lstm","FD001"),("tft","FD001"),("lstm","FD003"),("tft","FD003")]

def run(model, subset, args):
    cmd = [sys.executable, "train.py",
           "--model", model, "--subset", subset,
           "--data_dir", args.data_dir,
           "--epochs", str(args.epochs),
           "--checkpoint_dir", args.checkpoint_dir,
           "--results_dir", args.results_dir,
           "--no_wandb"]
    print(f"\n{'='*60}\nRunning: {model.upper()} / {subset}\n{'='*60}")
    r = subprocess.run(cmd, check=True)
    return r.returncode == 0

def summary(results_dir):
    print(f"\n{'='*60}\nFINAL RESULTS SUMMARY\n{'='*60}")
    print(f"{'Model':<10} {'Subset':<8} {'RMSE':>10} {'PHM':>12}")
    print("-"*60)
    for model, subset in EXPERIMENTS:
        p = os.path.join(results_dir, f"{model}_{subset}.json")
        if os.path.exists(p):
            r = json.load(open(p))
            print(f"{model.upper():<10} {subset:<8} {r['test_rmse']:>10.4f} {r['test_phm']:>12.2f}")
    print("="*60)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", default="./data")
    p.add_argument("--checkpoint_dir", default="./checkpoints")
    p.add_argument("--results_dir", default="./results")
    p.add_argument("--epochs", type=int, default=50)
    args = p.parse_args()
    for model, subset in EXPERIMENTS:
        run(model, subset, args)
    summary(args.results_dir)

if __name__ == "__main__":
    main()
