# RUL Prediction: LSTM vs Temporal Fusion Transformer
24-788 Introduction to Deep Learning, Spring 2026

## What this does

Trains and compares two models for Remaining Useful Life prediction on NASA C-MAPSS:
- LSTM (baseline, covered in class)
- Temporal Fusion Transformer (variant, Lim et al. NeurIPS 2020)

Run on FD001 and FD003 subsets for cross-subset analysis.

## Setup

```bash
pip install torch numpy pandas scikit-learn matplotlib wandb
```

## Data download

```
https://phm-datasets.s3.amazonaws.com/NASA/6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip
```

Unzip it. There is an inner CMAPSSData.zip — unzip that too. You want a flat folder
with train_FD001.txt, test_FD001.txt, RUL_FD001.txt etc. Pass that folder as --data_dir.

## Train all experiments

```bash
python run_all_experiments.py --data_dir /path/to/data --epochs 50
```

This trains all 4 combinations (LSTM/TFT x FD001/FD003) sequentially and prints a summary table.

## Train a single model

```bash
python train.py --model lstm --subset FD001 --data_dir /path/to/data --epochs 50
python train.py --model tft  --subset FD001 --data_dir /path/to/data --epochs 50
```

## Reproduce results

Open 24788_RUL_Project.ipynb in Google Colab (GPU runtime).
Run all cells top to bottom. Training takes about 60-80 minutes.

If you already have checkpoints and results JSONs, skip the training cell and run
from the results loading cell onwards. Update DATA_DIR at the top to match your path.

## Repository layout

```
models/
  lstm_baseline.py    stacked LSTM
  tft.py              Temporal Fusion Transformer
utils/
  data.py             loading, preprocessing, sliding window
  metrics.py          RMSE and asymmetric PHM score
train.py              training script
run_all_experiments.py  runs all 4 model/subset combinations
24788_RUL_Project.ipynb  main notebook for Colab
checkpoints/          saved model weights (best val RMSE per run)
results/              JSON files with metrics and predictions
figures/              output figures
```

## Results

| Model | FD001 RMSE | FD001 PHM | FD003 RMSE | FD003 PHM |
|-------|-----------|-----------|-----------|-----------|
| LSTM  | 13.46     | 341.51    | 12.15     | 246.40    |
| TFT   | 12.99     | 267.38    | 12.65     | 295.97    |

## References

- Lim et al., Temporal Fusion Transformers for Interpretable Multi-horizon Time Series Forecasting, NeurIPS 2020
- Zheng et al., Long Short-Term Memory Network for Remaining Useful Life Estimation, ICPHM 2017
- Saxena et al., Damage Propagation Modeling for Aircraft Engine Run-to-Failure Simulation, PHM 2008
