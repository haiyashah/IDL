"""
Temporal Fusion Transformer (Lim et al., NeurIPS 2020)
Adapted for single-step RUL regression on C-MAPSS.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class GatedLinearUnit(nn.Module):
    def forward(self, x):
        a, b = x.chunk(2, dim=-1)
        return a * torch.sigmoid(b)


class GatedResidualNetwork(nn.Module):
    def __init__(self, d_model, d_hidden=None, dropout=0.1):
        super().__init__()
        d_hidden = d_hidden or d_model
        self.fc1  = nn.Linear(d_model, d_hidden)
        self.fc2  = nn.Linear(d_hidden, d_model*2)
        self.glu  = GatedLinearUnit()
        self.norm = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, x):
        h = F.elu(self.fc1(x))
        h = self.drop(self.glu(self.fc2(h)))
        return self.norm(x + h)


class VariableSelectionNetwork(nn.Module):
    def __init__(self, n_features, d_model, dropout=0.1):
        super().__init__()
        self.n_features = n_features
        self.d_model = d_model
        self.feature_proj = nn.ModuleList([nn.Linear(1, d_model) for _ in range(n_features)])
        self.feature_grn  = nn.ModuleList([GatedResidualNetwork(d_model, dropout=dropout) for _ in range(n_features)])
        self.weight_net   = nn.Sequential(nn.Linear(n_features, d_model), nn.ELU(),
                                          nn.Dropout(dropout), nn.Linear(d_model, n_features))
        self.norm = nn.LayerNorm(d_model)

    def forward(self, x):
        B, T, F = x.shape
        weights = torch.softmax(self.weight_net(x), dim=-1)
        feats = []
        for i in range(self.n_features):
            fi = self.feature_proj[i](x[..., i:i+1])
            fi = self.feature_grn[i](fi)
            feats.append(fi)
        stacked = torch.stack(feats, dim=2)
        out = (stacked * weights.unsqueeze(-1)).sum(dim=2)
        return self.norm(out), weights


class TemporalFusionTransformer(nn.Module):
    def __init__(self, n_features, d_model=64, n_heads=4, n_lstm_layers=2, dropout=0.1):
        super().__init__()
        assert d_model % n_heads == 0
        self.vsn  = VariableSelectionNetwork(n_features, d_model, dropout)
        self.lstm = nn.LSTM(d_model, d_model, n_lstm_layers, batch_first=True,
                            dropout=dropout if n_lstm_layers>1 else 0.0)
        self.lstm_gate = nn.Linear(d_model, d_model)
        self.lstm_norm = nn.LayerNorm(d_model)
        self.attn      = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.attn_grn  = GatedResidualNetwork(d_model, dropout=dropout)
        self.attn_norm = nn.LayerNorm(d_model)
        self.ff_grn    = GatedResidualNetwork(d_model, d_hidden=d_model*2, dropout=dropout)
        self.head      = nn.Sequential(nn.Linear(d_model, 32), nn.ReLU(),
                                       nn.Dropout(dropout), nn.Linear(32, 1))

    def forward(self, x):
        vsn_out, _ = self.vsn(x)
        lstm_out, _ = self.lstm(vsn_out)
        gate = torch.sigmoid(self.lstm_gate(lstm_out))
        lstm_out = self.lstm_norm(vsn_out + gate * lstm_out)
        attn_out, _ = self.attn(lstm_out, lstm_out, lstm_out)
        attn_out = self.attn_grn(attn_out)
        attn_out = self.attn_norm(lstm_out + attn_out)
        ff_out = self.ff_grn(attn_out)
        return self.head(ff_out[:, -1, :])

    def get_variable_weights(self, x):
        _, weights = self.vsn(x)
        return weights
